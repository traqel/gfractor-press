gFractor 1.2.0 - Growl Audio press kit

Logos and screenshot are free to use in editorial coverage of gFractor.
Please do not alter the logo mark or colors outside of standard color corrections.
https://traqel.github.io/gfractor-press/
